from django.urls import path
from . import views

urlpatterns = [
    path('',views.home, name='home'),
    path('trabalheconosco/',views.trabalheconosco,name='trabalheconosco'),
    path('formulario/',views.formulario,name='formulario'),
    path('ondeestamos/',views.ondeestamos, name='ondeestamos'),
    path('areadousuario/',views.areadousuario,name='areadousuario'),
    path('resposta/',views.resposta, name='resposta'),
    path('novoformulario/',views.novoformulario,name='novoformulario'),
    path('login/',views.login, name='login'),
    path('logout/',views.logout, name='logout'),
    # path('dashboard/',views.dashboard, name='dashboard'),
    # path('editar/',views.editar, name='editar'),
    path('adicionar_candidato/',views.adicionar_candidato, name='formulario' ),
    path('listar_candidato/',views.listar_candidato, name='candidatos' ),
]