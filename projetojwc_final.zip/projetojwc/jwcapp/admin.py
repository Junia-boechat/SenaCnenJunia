from django.contrib import admin

# Register your models here.

from .models import Candidato
from .models import Login

admin.site.register(Candidato)
admin.site.register(Login)

# from .models import Empresa
# from .models import Cliente
# from .models import Pedidos

# admin.site.register(Produto)
# admin.site.register(Empresa)
# admin.site.register(Cliente)
# admin.site.register(Pedidos)