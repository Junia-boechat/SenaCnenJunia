# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.shortcuts import redirect
from django.contrib.auth import authenticate, login, logout
from .models import Candidato

           
def home(request):
 
    template = loader.get_template('main.html')
    return HttpResponse(template.render())

def trabalheconosco(request):
   
    template = loader.get_template('trabalheconosco.html')
    return HttpResponse(template.render())

def formulario(request):
 
    template = loader.get_template('formulario.html')
    return HttpResponse(template.render())

def ondeestamos(request):
   
    template = loader.get_template('ondeestamos.html')
    return HttpResponse(template.render())

def areadousuario(request):
   
    template = loader.get_template('areadousuario.html')
    return HttpResponse(template.render())

def novoformulario(request):
 
    template = loader.get_template('novoformulario.html')
    return HttpResponse(template.render())

def resposta(request):
 
    template = loader.get_template('resposta.html')
    return HttpResponse(template.render())

'Criar depois os htmls'
def login(request):
   
    template = loader.get_template('login.html')
    return HttpResponse(template.render())

def logout(request):
   
    template = loader.get_template('logout.html')
    return HttpResponse(template.render())


# def dashboard(request):
   
#     template = loader.get_template('dashboard.html')
#     return HttpResponse(template.render())

# def editar(request):
   
#     template = loader.get_template('editar.html')
#     return HttpResponse(template.render())

def adicionar_candidato(request):
    if request.method == 'POST':
        CPF = request.POST['CPF']
        nome = request.POST['nome']
        endereco = request.POST['endereco']
        bairro = request.POST['bairro']
        complemento = request.POST['complemento']
        email = request.POST['email']
        telefone = request.POST['telefone']
       # data_nascimento = request.POST['data_nascimento']
        Candidato.objects.create(CPF=CPF,nome=nome,endereco=endereco,bairro=bairro,complemento=complemento, email=email, telefone=telefone)
        return redirect('candidatos')
    return render(request, 'formulario.html')
    #return render(request, 'adicionar_cliente.html')

# def listar_candidato(request):
#     template = loader.get_template('listarcandidato.html')
#     return HttpResponse(template.render())

def listar_candidato(request): ###QUERYSET
    candidatos = Candidato.objects.all()
    return render(request, 'listar_candidato.html', {'candidatos': candidatos})
   

def login(request):
     if request.method == 'POST':
         username = request.POST['username']
         password = request.POST['password']
         user = authenticate(request, username=username, password=password)
         if user is not None:
             login(request, user)
             return redirect('home')
         else:
             return render(request, 'login.html', {'error': 'Credenciais inválidas'})
     return render(request, 'login.html')

def logout(request):
     logout(request)
     return redirect('login')
