from django import forms
from .models import Candidato
from .models import Login

class CandidatoForm(forms.ModelForm):
    class Meta:
        model = Candidato
        fields = ['CPF','nome', 'endereco', 'bairro','complemento','telefone','email' ]

class LoginForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ['username','password']
