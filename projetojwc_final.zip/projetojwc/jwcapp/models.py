from django.db import models

# Create your models here.

class Candidato(models.Model):
    id = models.AutoField(primary_key=True)
    CPF = models.CharField(max_length=11)
    nome = models.CharField(max_length=100)
    endereco = models.CharField(max_length=100)
    bairro = models.CharField(max_length=100)
    complemento = models.CharField(max_length=30)
    email = models.EmailField(default='example@mail.com')
    telefone = models.CharField(max_length=15,default='(xx)xxxxx-xxxx')
    #imagem = models.ImageField(upload_to='produtos/', blank=True, null=True)
   
    def __str__(self):
        return self.nome
    
class Login(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    
    def __str__(self):
        return self.login

    
# class Empresa(models.Model):
#     cnpj = models.CharField(primary_key=True,max_length=11)
#     nome = models.CharField(max_length=100)
#     endereco = models.CharField(max_length=100)
#     nome_fantasia = models.CharField(max_length=100)
#     inscricao_estadual = models.CharField(max_length=14)
#     tipo = models.CharField(max_length=6) #dizer se ela é filial ou master

#     def __str__(self):
#         return self.nome
    
# class Pedidos(models.Model):
#     codigodacompra = models.AutoField(primary_key=True) 
#    # codigoproduto = models.CharField(max_length=4,default=0000)
#     valor = models.DecimalField(max_digits=10, decimal_places=2)
#     cpf =  models.CharField(max_length=11)
#     codigoproduto = models.ManyToManyField(Produto)
    
#     def __str__(self):
#         return self.valor

# class Cliente(models.Model):
#     cpf = models.CharField(max_length=11)
#     nome = models.CharField(max_length=100)
#     endereco = models.CharField(max_length=100)
#     cidade = models.CharField(max_length=50)
#     #cnpj = models.CharField(max_length=11)
#     cnpj = models.ForeignKey(Empresa, on_delete=models.CASCADE)

#     def __str__(self):
#         return self.nome





    